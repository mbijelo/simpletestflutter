package com.example.simpletestflutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
